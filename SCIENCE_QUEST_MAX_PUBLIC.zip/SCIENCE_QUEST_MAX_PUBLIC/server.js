// SCIENCE QUEST MAX — Node.js 18+, zero third-party dependencies
// Public-service starter. For production, put behind HTTPS reverse proxy and use a persistent disk/database.
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = __dirname;
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const MAX_BODY = 1_000_000;
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;

if (!ADMIN_KEY || ADMIN_KEY.length < 32) {
  const msg = 'ADMIN_KEY must be set to a random secret of at least 32 characters.';
  if (process.env.NODE_ENV === 'production') throw new Error(msg);
  console.warn('WARNING: ' + msg);
}
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], scores: [], questions: [] }, null, 2), { mode: 0o600 });
}
try { fs.chmodSync(DB_FILE, 0o600); } catch {}

function readDB() {
  try {
    const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return { users: Array.isArray(db.users) ? db.users : [], scores: Array.isArray(db.scores) ? db.scores : [], questions: Array.isArray(db.questions) ? db.questions : [] };
  } catch (e) {
    console.error('Database read failed:', e.message);
    return { users: [], scores: [], questions: [] };
  }
}
function writeDB(db) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
  try { fs.chmodSync(DB_FILE, 0o600); } catch {}
}
const sessions = new Map();
const quizSessions = new Map();
// Basic per-IP throttling. For multi-instance production deployments, use a shared rate-limit store at the proxy/API layer.
const requestBuckets = new Map();
function rateLimited(req) {
  const now = Date.now();
  // Never trust client-supplied X-Forwarded-For unless the deployment explicitly opts in.
  const forwarded = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean);
  const ip = process.env.TRUST_PROXY === '1' && forwarded.length
    ? forwarded[forwarded.length - 1]
    : String(req.socket.remoteAddress || 'unknown');
  const key = ip + ':' + (req.url.startsWith('/api/auth/') ? 'auth' : req.url.startsWith('/api/admin/') ? 'admin' : 'api');
  const limit = key.endsWith(':auth') ? 15 : key.endsWith(':admin') ? 120 : 300;
  let b = requestBuckets.get(key);
  if (!b || now - b.start > 60_000) b = { start: now, count: 0 };
  b.count++; requestBuckets.set(key, b);
  if (requestBuckets.size > 5000) {
    for (const [k, v] of requestBuckets) if (now - v.start > 120_000) requestBuckets.delete(k);
  }
  return b.count > limit;
}
function send(res, status, data, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    ...headers
  });
  res.end(JSON.stringify(data));
}
function body(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', c => {
      s += c;
      if (s.length > MAX_BODY) { reject(new Error('요청 본문이 너무 큽니다.')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(s ? JSON.parse(s) : {}); }
      catch { reject(new Error('JSON 형식이 올바르지 않습니다.')); }
    });
    req.on('error', reject);
  });
}
function token() { return crypto.randomBytes(32).toString('hex'); }
function issueSession(userId) {
  const now = Date.now();
  for (const [key, value] of sessions) if (value.expires < now) sessions.delete(key);
  // Keep memory bounded if the service receives sustained account/session churn.
  while (sessions.size >= 100000) sessions.delete(sessions.keys().next().value);
  const t = token(); sessions.set(t, { userId, expires: now + SESSION_MS });
  return t;
}
function hashPassword(password, salt) { return crypto.scryptSync(password, salt, 64); }
function passwordMatches(password, salt, expectedHex) {
  try {
    const actual = hashPassword(password, salt), expected = Buffer.from(String(expectedHex || ''), 'hex');
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}
function safeUser(u) { return { id: u.id, username: u.username, createdAt: u.createdAt }; }
function auth(req) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return null;
  const t = h.slice(7), s = sessions.get(t);
  if (!s || s.expires < Date.now()) { sessions.delete(t); return null; }
  return s.userId;
}
function requireAdmin(req) {
  const supplied = req.headers['x-admin-key'];
  if (!ADMIN_KEY || ADMIN_KEY.length < 24 || typeof supplied !== 'string') return false;
  const a = Buffer.from(supplied), b = Buffer.from(ADMIN_KEY);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function validateQuestion(b, id = crypto.randomUUID()) {
  const q = String(b.q || '').trim();
  const a = Array.isArray(b.a) ? b.a.map(x => String(x).trim()) : [];
  const c = Number(b.c), e = String(b.e || '').trim();
  const t = String(b.t || '과학상식').trim().slice(0, 60);
  const d = String(b.d || '보통');
  const h = String(b.h || '').trim().slice(0, 300);
  if (q.length < 5 || q.length > 1000 || a.length !== 4 || a.some(x => !x || x.length > 300) ||
      !Number.isInteger(c) || c < 0 || c > 3 || e.length < 2 || e.length > 2000) {
    throw new Error('문제(5~1000자), 선택지 4개(각 1~300자), 정답, 해설(2~2000자)을 확인하세요.');
  }
  if (!['쉬움', '보통', '어려움'].includes(d)) throw new Error('난이도는 쉬움/보통/어려움 중 하나여야 합니다.');
  return { id, q, a, c, e, t: t || '과학상식', d, h, updatedAt: new Date().toISOString() };
}
function publicQuestion(q) {
  return { id: q.id, q: q.q, a: q.a, t: q.t, d: q.d, h: q.h || '' };
}
function routeStatic(req, res) {
  // Explicit allowlist prevents access to data/, server source, package files, and environment files.
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Bad request'); }
  const allowed = new Map([
    ['/', 'science_quest_server.html'],
    ['/science_quest_server.html', 'science_quest_server.html'],
    ['/privacy.html', 'PRIVACY_POLICY_TEMPLATE.html'],
    ['/terms.html', 'TERMS_TEMPLATE.html'],
    ['/favicon.ico', null]
  ]);
  if (pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  const file = allowed.get(pathname);
  if (!file) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
  const target = path.join(ROOT, file);
  fs.readFile(target, (err, content) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data: https:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'",
      'Referrer-Policy': 'same-origin'
    });
    res.end(content);
  });
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost'), p = url.pathname;
  if (p.startsWith('/api/') && rateLimited(req)) return send(res, 429, { error: '요청이 너무 많습니다. 잠시 후 다시 시도하세요.' }, { 'Retry-After': '60' });
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': 'same-origin', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Admin-Key' });
    return res.end();
  }
  if (req.method === 'GET' && p === '/api/health') {
    try { readDB(); return send(res, 200, { ok: true, service: 'SCIENCE QUEST MAX API', version: 3, time: new Date().toISOString() }); }
    catch { return send(res, 503, { ok: false, error: '서비스를 일시적으로 사용할 수 없습니다.' }); }
  }

  if (req.method === 'GET' && p === '/api/questions') {
    const db = readDB();
    const difficulty = url.searchParams.get('difficulty');
    const topic = url.searchParams.get('topic');
    let questions = db.questions;
    if (difficulty && ['쉬움', '보통', '어려움'].includes(difficulty)) questions = questions.filter(q => q.d === difficulty);
    if (topic) questions = questions.filter(q => q.t === topic);
    return send(res, 200, { questions: questions.map(publicQuestion), count: questions.length });
  }

  if (req.method === 'GET' && p === '/api/leaderboard') {
    const db = readDB(), map = new Map();
    for (const s of db.scores) {
      const u = db.users.find(x => x.id === s.userId); if (!u) continue;
      const x = map.get(u.id) || { username: u.username, bestScore: 0, bestPercent: 0, plays: 0, totalScore: 0 };
      x.plays++; x.totalScore += s.score;
      if (s.score > x.bestScore) { x.bestScore = s.score; x.bestPercent = s.total ? Math.round(s.correct / s.total * 100) : 0; }
      map.set(u.id, x);
    }
    const items = [...map.values()].sort((a,b) => b.bestScore-a.bestScore || b.bestPercent-a.bestPercent || b.plays-a.plays).slice(0,20);
    return send(res, 200, { items });
  }

  if (req.method === 'POST' && p === '/api/auth/register') {
    try {
      const b = await body(req), username = String(b.username || '').trim(), password = String(b.password || '');
      if (username.length < 2 || username.length > 20) return send(res, 400, { error: '사용자 이름은 2~20자여야 합니다.' });
      if (!/^[\p{L}\p{N}_-]+$/u.test(username)) return send(res, 400, { error: '이름은 문자, 숫자, _, -만 사용할 수 있습니다.' });
      if (password.length < 8 || password.length > 256) return send(res, 400, { error: '비밀번호는 8~256자여야 합니다.' });
      const db = readDB();
      if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) return send(res, 409, { error: '이미 사용 중인 이름입니다.' });
      const salt = crypto.randomBytes(16).toString('hex'), u = { id: crypto.randomUUID(), username, salt, passwordHash: hashPassword(password, salt).toString('hex'), createdAt: new Date().toISOString() };
      db.users.push(u); writeDB(db);
      const t = issueSession(u.id);
      return send(res, 201, { token: t, user: safeUser(u) });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (req.method === 'POST' && p === '/api/auth/login') {
    try {
      const b = await body(req), db = readDB(), username = String(b.username || '').trim();
      const u = db.users.find(x => x.username.toLowerCase() === username.toLowerCase());
      if (!u || !passwordMatches(String(b.password || ''), u.salt, u.passwordHash)) return send(res, 401, { error: '아이디 또는 비밀번호가 올바르지 않습니다.' });
      const t = issueSession(u.id);
      return send(res, 200, { token: t, user: safeUser(u) });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (req.method === 'POST' && p === '/api/quiz/start') {
    const uid = auth(req); if (!uid) return send(res, 401, { error: '서버 문제 퀴즈를 시작하려면 로그인하세요.' });
    try {
      const b = await body(req), ids = b.questionIds;
      if (!Array.isArray(ids) || ids.length < 1 || ids.length > 100 || ids.some(id => typeof id !== 'string') || new Set(ids).size !== ids.length) return send(res, 400, { error: '문제 ID 목록이 올바르지 않습니다.' });
      const db = readDB();
      if (ids.some(id => !db.questions.some(q => q.id === id))) return send(res, 400, { error: '등록되지 않은 서버 문제가 포함되어 있습니다.' });
      const now = Date.now();
      for (const [id, v] of quizSessions) if (v.expires < now || v.submitted) quizSessions.delete(id);
      const quizId = token();
      quizSessions.set(quizId, { userId: uid, questionIds: ids, answers: new Map(), expires: now + 60 * 60 * 1000, submitted: false });
      return send(res, 201, { quizId, questionCount: ids.length, expiresInSeconds: 3600 });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (req.method === 'POST' && p === '/api/quiz/answer') {
    const uid = auth(req); if (!uid) return send(res, 401, { error: '먼저 서버 계정으로 로그인하세요.' });
    try {
      const b = await body(req), quizId = String(b.quizId || ''), id = String(b.questionId || ''), chosen = Number(b.chosen);
      if (!quizId || !id || !Number.isInteger(chosen) || chosen < -1 || chosen > 3) return send(res, 400, { error: '답안 형식이 올바르지 않습니다.' });
      const quiz = quizSessions.get(quizId);
      if (!quiz || quiz.userId !== uid || quiz.expires < Date.now() || quiz.submitted) return send(res, 410, { error: '퀴즈 세션이 만료되었거나 올바르지 않습니다.' });
      if (!quiz.questionIds.includes(id)) return send(res, 400, { error: '이 퀴즈에 포함되지 않은 문제입니다.' });
      if (quiz.answers.has(id)) return send(res, 409, { error: '이미 제출한 문제입니다.' });
      const q = readDB().questions.find(x => x.id === id);
      if (!q) return send(res, 404, { error: '서버 문제를 찾을 수 없습니다.' });
      const correct = chosen === q.c;
      quiz.answers.set(id, { chosen, correct });
      return send(res, 200, { correct, explanation: q.e });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  // Server-authoritative grading for developer-managed questions.
  if (req.method === 'POST' && p === '/api/quiz/submit') {
    const uid = auth(req); if (!uid) return send(res, 401, { error: '먼저 서버 계정으로 로그인하세요.' });
    try {
      const b = await body(req), quizId = String(b.quizId || ''), quiz = quizSessions.get(quizId);
      if (!quiz || quiz.userId !== uid || quiz.expires < Date.now() || quiz.submitted) return send(res, 410, { error: '퀴즈 세션이 만료되었거나 이미 제출되었습니다.' });
      if (quiz.answers.size !== quiz.questionIds.length) return send(res, 400, { error: '모든 문제에 답한 뒤 결과를 제출하세요.' });
      const correct = [...quiz.answers.values()].filter(a => a.correct).length;
      const total = quiz.questionIds.length, score = correct * 10;
      const db = readDB();
      db.scores.push({ id: crypto.randomUUID(), userId: uid, score, correct, total, mode: String(b.mode || 'classic').slice(0,20), topic: String(b.topic || 'all').slice(0,40), difficulty: String(b.difficulty || 'all').slice(0,20), createdAt: new Date().toISOString(), verified: true });
      writeDB(db); quiz.submitted = true; quizSessions.delete(quizId);
      return send(res, 201, { ok: true, score, correct, total });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (req.method === 'POST' && p === '/api/scores') {
    return send(res, 410, { error: '클라이언트 점수는 공식 순위에 등록할 수 없습니다. 서버 문제는 /api/quiz/submit으로 제출하세요.' });
  }

  if (p.startsWith('/api/admin/')) {
    if (!requireAdmin(req)) return send(res, 403, { error: '관리자 키가 없거나 올바르지 않습니다. ADMIN_KEY 환경 변수를 확인하세요.' });
    if (req.method === 'GET' && p === '/api/admin/status') {
      const db = readDB();
      return send(res, 200, { ok: true, questionCount: db.questions.length, userCount: db.users.length, scoreCount: db.scores.length, storage: 'json-file' });
    }
    if (req.method === 'GET' && p === '/api/admin/questions') return send(res, 200, { questions: readDB().questions });
    if (req.method === 'POST' && p === '/api/admin/questions') {
      try {
        const b = await body(req), item = validateQuestion(b), db = readDB();
        db.questions.push(item); writeDB(db);
        return send(res, 201, { ok: true, question: item });
      } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (req.method === 'PUT' && p.startsWith('/api/admin/questions/')) {
      try {
        let id; try { id = decodeURIComponent(p.slice('/api/admin/questions/'.length)); } catch { return send(res, 400, { error: '문제 ID 형식이 올바르지 않습니다.' }); }
        const b = await body(req), db = readDB();
        const idx = db.questions.findIndex(q => q.id === id);
        if (idx < 0) return send(res, 404, { error: '문제를 찾을 수 없습니다.' });
        db.questions[idx] = validateQuestion(b, id);
        db.questions[idx].createdAt = db.questions[idx].createdAt || new Date().toISOString();
        writeDB(db); return send(res, 200, { ok: true, question: db.questions[idx] });
      } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (req.method === 'DELETE' && p.startsWith('/api/admin/questions/')) {
      let id; try { id = decodeURIComponent(p.slice('/api/admin/questions/'.length)); } catch { return send(res, 400, { error: '문제 ID 형식이 올바르지 않습니다.' }); }
      const db = readDB(), before = db.questions.length;
      db.questions = db.questions.filter(q => q.id !== id);
      if (before === db.questions.length) return send(res, 404, { error: '문제를 찾을 수 없습니다.' });
      writeDB(db); return send(res, 200, { ok: true, deleted: id });
    }
    if (req.method === 'POST' && p === '/api/admin/questions/import') {
      try {
        const b = await body(req);
        if (!Array.isArray(b.questions) || b.questions.length > 2000) return send(res, 400, { error: 'questions 배열(최대 2000개)이 필요합니다.' });
        const incoming = b.questions.map(q => validateQuestion(q));
        const db = readDB();
        if (b.replace === true) db.questions = incoming;
        else {
          const existing = new Set(db.questions.map(q => q.id));
          for (const q of incoming) { if (existing.has(q.id)) q.id = crypto.randomUUID(); db.questions.push(q); }
        }
        writeDB(db); return send(res, 200, { ok: true, questionCount: db.questions.length });
      } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (req.method === 'GET' && p === '/api/admin/export') {
      const db = readDB();
      return send(res, 200, { exportedAt: new Date().toISOString(), questions: db.questions });
    }
  }

  if (p.startsWith('/api/')) return send(res, 404, { error: 'API 경로를 찾을 수 없습니다.' });
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end('Method Not Allowed'); }
  return routeStatic(req, res);
});
server.listen(PORT, '0.0.0.0', () => console.log(`SCIENCE QUEST MAX server listening on port ${PORT}`));
