'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');

let child, base, tmp, port;
const adminKey = 'test-admin-key-' + require('node:crypto').randomBytes(24).toString('hex');

async function freePort() {
  return await new Promise((resolve, reject) => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); });
    s.on('error', reject);
  });
}
async function waitForServer() {
  for (let i = 0; i < 100; i++) {
    if (child.exitCode !== null) throw new Error('Server exited before becoming ready');
    try { const r = await fetch(base + '/api/health'); if (r.ok) return; } catch {}
    await new Promise(r => setTimeout(r, 50));
  }
  throw new Error('Server did not become ready');
}
async function request(url, options = {}) {
  const r = await fetch(base + url, options);
  const type = r.headers.get('content-type') || '';
  return { status: r.status, data: type.includes('json') ? await r.json() : await r.text(), headers: r.headers };
}
const json = (method, body, extraHeaders = {}) => ({ method, headers: { 'content-type': 'application/json', ...extraHeaders }, body: JSON.stringify(body) });
const admin = { 'x-admin-key': adminKey };

 test('SCIENCE QUEST API integration and security smoke tests', async t => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'science-quest-test-'));
  port = await freePort(); base = `http://127.0.0.1:${port}`;
  child = spawn(process.execPath, [path.join(__dirname, 'server.js')], {
    cwd: __dirname,
    env: { ...process.env, PORT: String(port), ADMIN_KEY: adminKey, DATA_DIR: tmp },
    stdio: ['ignore', 'ignore', 'pipe']
  });
  let stderr = ''; child.stderr.on('data', c => stderr += c.toString());
  t.after(() => {
    if (child && child.exitCode === null) child.kill('SIGTERM');
    if (tmp) fs.rmSync(tmp, { recursive: true, force: true });
  });
  await waitForServer();

  await t.test('health and static page', async () => {
    const h = await request('/api/health'); assert.equal(h.status, 200); assert.equal(h.data.ok, true);
    const page = await request('/'); assert.equal(page.status, 200); assert.match(page.data, /SCIENCE QUEST/);
    const privacy = await request('/privacy.html'); assert.equal(privacy.status, 200); assert.match(privacy.data, /개인정보 처리방침/);
    const terms = await request('/terms.html'); assert.equal(terms.status, 200); assert.match(terms.data, /이용약관/);
  });
  await t.test('private files and unknown routes are not served', async () => {
    assert.equal((await request('/server.js')).status, 404);
    assert.equal((await request('/data/db.json')).status, 404);
    assert.equal((await request('/.env')).status, 404);
    assert.equal((await request('/not-found')).status, 404);
  });
  await t.test('registration, duplicate name and login', async () => {
    assert.equal((await request('/api/auth/register', json('POST', { username: 'a', password: '12345678' }))).status, 400);
    const reg = await request('/api/auth/register', json('POST', { username: 'Tester_1', password: 'CorrectHorseBatteryStaple123!' }));
    assert.equal(reg.status, 201); assert.ok(reg.data.token); assert.equal(reg.data.user.username, 'Tester_1');
    assert.equal((await request('/api/auth/register', json('POST', { username: 'tester_1', password: 'CorrectHorseBatteryStaple123!' }))).status, 409);
    assert.equal((await request('/api/auth/login', json('POST', { username: 'Tester_1', password: 'wrong-password' }))).status, 401);
    const login = await request('/api/auth/login', json('POST', { username: 'Tester_1', password: 'CorrectHorseBatteryStaple123!' }));
    assert.equal(login.status, 200); assert.ok(login.data.token);
    globalThis.testToken = reg.data.token;
  });
  await t.test('admin key protects management API', async () => {
    assert.equal((await request('/api/admin/status')).status, 403);
    assert.equal((await request('/api/admin/status', { headers: { 'x-admin-key': 'wrong' } })).status, 403);
    const s = await request('/api/admin/status', { headers: admin }); assert.equal(s.status, 200); assert.equal(s.data.questionCount, 0);
  });
  let questionId;
  await t.test('question CRUD, validation and public answer-key hiding', async () => {
    const bad = await request('/api/admin/questions', json('POST', { q: 'bad', a: ['1'], c: 8, e: '' }, admin)); assert.equal(bad.status, 400);
    const payload = { q: '물의 화학식은 무엇인가요?', a: ['CO2', 'H2O', 'O2', 'NaCl'], c: 1, e: '물은 H2O입니다.', t: '화학', d: '쉬움', h: '분자식을 생각해 보세요.' };
    const created = await request('/api/admin/questions', json('POST', payload, admin)); assert.equal(created.status, 201); questionId = created.data.question.id;
    const pub = await request('/api/questions'); assert.equal(pub.status, 200); assert.equal(pub.data.count, 1);
    assert.equal(pub.data.questions[0].q, payload.q); assert.equal('c' in pub.data.questions[0], false); assert.equal('e' in pub.data.questions[0], false);
    const updated = await request('/api/admin/questions/' + questionId, json('PUT', { ...payload, q: '수정된 물의 화학식은 무엇인가요?' }, admin)); assert.equal(updated.status, 200);
    assert.equal((await request('/api/admin/export', { headers: admin })).data.questions.length, 1);
    assert.equal((await request('/api/admin/questions/' + questionId, { method: 'DELETE', headers: admin })).status, 200);
    assert.equal((await request('/api/admin/questions/' + questionId, { method: 'DELETE', headers: admin })).status, 404);
  });
  await t.test('server-authoritative grading and client-score rejection', async () => {
    const token = globalThis.testToken, authHeader = { authorization: 'Bearer ' + token };
    assert.equal((await request('/api/scores', json('POST', { score: 999999, correct: 1, total: 1 }, authHeader))).status, 410);
    const payload = { q: '빛의 속도는 어떤 매질에서 가장 빠른가요?', a: ['물', '유리', '진공', '기름'], c: 2, e: '빛은 진공에서 가장 빠르게 이동합니다.', t: '물리', d: '쉬움', h: '매질을 생각해 보세요.' };
    const created = await request('/api/admin/questions', json('POST', payload, admin)); assert.equal(created.status, 201);
    const id = created.data.question.id;
    const noAuth = await request('/api/quiz/answer', json('POST', { questionId: id, chosen: 2 })); assert.equal(noAuth.status, 401);
    const started = await request('/api/quiz/start', json('POST', { questionIds: [id] }, authHeader));
    assert.equal(started.status, 201); const quizId = started.data.quizId;
    const answer = await request('/api/quiz/answer', json('POST', { quizId, questionId: id, chosen: 2 }, authHeader));
    assert.equal(answer.status, 200); assert.equal(answer.data.correct, true); assert.equal('correctIndex' in answer.data, false);
    assert.equal((await request('/api/quiz/answer', json('POST', { quizId, questionId: id, chosen: 0 }, authHeader))).status, 409);
    const submitted = await request('/api/quiz/submit', json('POST', { quizId }, authHeader));
    assert.equal(submitted.status, 201); assert.equal(submitted.data.correct, 1); assert.equal(submitted.data.score, 10);
    assert.equal((await request('/api/quiz/submit', json('POST', { quizId }, authHeader))).status, 410);
    const ranks = await request('/api/leaderboard'); assert.equal(ranks.status, 200); assert.equal(ranks.data.items[0].username, 'Tester_1');
  });
  await t.test('malformed encoded URL does not crash the server', async () => {
    const r = await request('/%E0%A4%A'); assert.ok([400, 404].includes(r.status));
    assert.equal((await request('/api/health')).status, 200);
  });
  assert.equal(child.exitCode, null, `server unexpectedly exited: ${stderr}`);
});
